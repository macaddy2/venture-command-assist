export type Tier = "Active Build" | "Incubating" | "Parked";
export type Geo = "UK" | "NG";

export interface Milestone {
  name: string;
  target: string;
  progress: number;
}

export interface TaskBreakdown {
  total: number;
  done: number;
  inProgress: number;
  blocked: number;
  backlog: number;
}

export interface TeamRole {
  title: string;
  priority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  status: "Filled" | "Hiring" | "Later";
}

export interface TeamInfo {
  filled: number;
  total: number;
  roles: TeamRole[];
}

export interface RegChecklist {
  domain: boolean;
  company: boolean;
  bank: boolean;
  legal: boolean;
}

export interface GitHubInfo {
  repos: number;
  commits7d: number;
  prsOpen: number;
  lastActivity: string;
}

export interface EquityHolder {
  name: string;
  percent: number;
  notes: string;
}

export interface Venture {
  id: string;
  name: string;
  prefix: string;
  geo: Geo;
  tier: Tier;
  color: string;
  description: string;
  status: string;
  stage: string;
  parent?: string;
  tasks: TaskBreakdown;
  team: TeamInfo;
  regs: RegChecklist;
  github: GitHubInfo;
  milestones: Milestone[];
  equity: EquityHolder[];
  adeEffectiveOwnership: number;
  weeklyFocus?: string;
  nextActions: string[];
  notes?: string;
}

export interface ScheduleEntry {
  day: string;
  am: string;
  pm: string;
  notes: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export const DEFAULT_VENTURES: Venture[] = [
  {
    id: "tc", name: "TruCycle", prefix: "TC", geo: "UK", tier: "Active Build",
    color: "#16a34a",
    description: "Circular economy: bulky waste collection, marketplace resale, upcycling, e-waste recycling",
    status: "Registered (May 2025)", stage: "MVP Development",
    tasks: { total: 24, done: 8, inProgress: 5, blocked: 1, backlog: 10 },
    team: {
      filled: 1, total: 5,
      roles: [
        { title: "CTO / Lead Developer", priority: "CRITICAL", status: "Hiring" },
        { title: "Operations & Logistics Lead", priority: "CRITICAL", status: "Hiring" },
        { title: "UX/UI Designer", priority: "HIGH", status: "Hiring" },
        { title: "Marketing & Growth Lead", priority: "HIGH", status: "Hiring" },
        { title: "BD / Partnerships", priority: "MEDIUM", status: "Later" },
      ]
    },
    regs: { domain: true, company: true, bank: false, legal: true },
    github: { repos: 3, commits7d: 0, prsOpen: 0, lastActivity: "Awaiting CTO" },
    milestones: [
      { name: "MVP Launch", target: "2026-06", progress: 33 },
      { name: "First 100 Users", target: "2026-08", progress: 0 },
    ],
    equity: [
      { name: "Ade (Founder)", percent: 35, notes: "Fully vested" },
      { name: "CTO (to hire)", percent: 18, notes: "4yr/12mo cliff" },
      { name: "Ops Lead (to hire)", percent: 12, notes: "4yr/12mo cliff" },
      { name: "UX Designer (to hire)", percent: 8, notes: "4yr/12mo cliff" },
      { name: "Marketing Lead (to hire)", percent: 7, notes: "4yr/12mo cliff" },
      { name: "Employee Pool", percent: 10, notes: "Future hires" },
      { name: "Investor Reserve", percent: 10, notes: "Seed round" },
    ],
    adeEffectiveOwnership: 35,
    weeklyFocus: "Mon (all day) + Wed AM",
    nextActions: [
      "Continue MVP development",
      "Finalize founding team equity onboarding",
      "Begin CTO / Lead Developer recruitment",
      "Secure pilot partnerships",
    ]
  },
  {
    id: "dg", name: "DepositGuard", prefix: "DG", geo: "UK", tier: "Active Build",
    color: "#2563eb",
    description: "Rental deposit recovery: guarantees tenants ~80% payout via claim assignment model",
    status: "Pending Registration", stage: "Pre-Registration",
    tasks: { total: 18, done: 3, inProgress: 4, blocked: 2, backlog: 9 },
    team: {
      filled: 1, total: 4,
      roles: [
        { title: "Lead Developer (Full-Stack)", priority: "CRITICAL", status: "Hiring" },
        { title: "Legal & Compliance Advisor", priority: "CRITICAL", status: "Hiring" },
        { title: "Product / UX Designer", priority: "HIGH", status: "Hiring" },
        { title: "Marketing & Tenant Acquisition", priority: "HIGH", status: "Later" },
      ]
    },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 2, commits7d: 0, prsOpen: 0, lastActivity: "Awaiting Dev" },
    milestones: [
      { name: "Ltd Registration", target: "2026-03", progress: 20 },
      { name: "Legal Model Validated", target: "2026-04", progress: 40 },
      { name: "Platform Beta", target: "2026-07", progress: 0 },
    ],
    equity: [
      { name: "Ade (Founder)", percent: 35, notes: "Fully vested" },
      { name: "Lead Dev (to hire)", percent: 18, notes: "4yr/12mo cliff" },
      { name: "Legal Advisor (to hire)", percent: 10, notes: "4yr/12mo cliff + retainer" },
      { name: "UX Designer (to hire)", percent: 7, notes: "4yr/12mo cliff" },
      { name: "Employee Pool", percent: 15, notes: "Future hires" },
      { name: "Investor Reserve", percent: 15, notes: "Seed round" },
    ],
    adeEffectiveOwnership: 35,
    weeklyFocus: "Tue (all day)",
    nextActions: [
      "Register Ltd company",
      "Get solicitor opinion on claim assignment model",
      "Build landing page for early traction",
    ]
  },
  {
    id: "pm", name: "PathMate", prefix: "PM", geo: "UK", tier: "Incubating",
    color: "#7c3aed",
    description: "Social rideshare: connects drivers and riders heading same direction for cost-sharing",
    status: "Concept", stage: "Research & Validation",
    tasks: { total: 12, done: 1, inProgress: 2, blocked: 0, backlog: 9 },
    team: {
      filled: 0, total: 5,
      roles: [
        { title: "Lead Mobile Developer", priority: "CRITICAL", status: "Later" },
        { title: "Backend / Infra Engineer", priority: "CRITICAL", status: "Later" },
        { title: "UX/UI Designer", priority: "HIGH", status: "Later" },
        { title: "Community & Growth Manager", priority: "HIGH", status: "Later" },
        { title: "Regulatory & Safety Lead", priority: "MEDIUM", status: "Later" },
      ]
    },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [
      { name: "Competitive Analysis", target: "2026-04", progress: 10 },
      { name: "Company Registration", target: "2026-05", progress: 0 },
    ],
    equity: [
      { name: "Ade (Founder)", percent: 50, notes: "Fully vested" },
      { name: "Lead Mobile Dev (to hire)", percent: 15, notes: "4yr/12mo cliff" },
      { name: "Backend Eng (to hire)", percent: 10, notes: "4yr/12mo cliff" },
      { name: "Employee Pool", percent: 10, notes: "Future hires" },
      { name: "Investor Reserve", percent: 15, notes: "Seed round" },
    ],
    adeEffectiveOwnership: 50,
    weeklyFocus: "Thu PM",
    nextActions: [
      "Complete competitive analysis (BlaBlaCar, Liftshare)",
      "Regulatory landscape research",
      "Register company",
    ]
  },
  {
    id: "fl", name: "Fixars Laboratories", prefix: "FL", geo: "UK", tier: "Incubating",
    color: "#0891b2",
    description: "AI think tank & solutions laboratory — developing, fine-tuning, and deploying AI solutions. fixars.ai",
    status: "Pending Registration", stage: "Pre-Registration",
    parent: "Fixars Group (51%)",
    tasks: { total: 15, done: 1, inProgress: 2, blocked: 1, backlog: 11 },
    team: {
      filled: 1, total: 5,
      roles: [
        { title: "Head of AI / Chief Scientist", priority: "CRITICAL", status: "Hiring" },
        { title: "Lead ML Engineer", priority: "HIGH", status: "Hiring" },
        { title: "Product / Solutions Lead", priority: "HIGH", status: "Later" },
        { title: "Full-Stack Dev (Platform)", priority: "MEDIUM", status: "Later" },
      ]
    },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [
      { name: "Register Fixars Group (CAC) first", target: "2026-03", progress: 15 },
      { name: "Register UK Ltd", target: "2026-04", progress: 0 },
      { name: "First AI prototype", target: "2026-07", progress: 0 },
    ],
    equity: [
      { name: "Fixars Group Ltd (NG)", percent: 51, notes: "Parent company PSC" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Head of AI (to hire)", percent: 10, notes: "4yr/12mo cliff" },
      { name: "Lead ML Engineer (to hire)", percent: 7, notes: "4yr/12mo cliff" },
      { name: "Product Lead (to hire)", percent: 5, notes: "4yr/12mo cliff" },
      { name: "Employee Pool", percent: 7, notes: "ML engineers, data scientists" },
      { name: "Investor Reserve", percent: 5, notes: "Seed/angel round" },
    ],
    adeEffectiveOwnership: 63.45,
    weeklyFocus: "Thu AM (with Fixars)",
    nextActions: [
      "Register Fixars Group at CAC FIRST",
      "Secure UK registered office address",
      "Register Fixars Laboratories at Companies House",
      "Begin recruiting Nigerian-based ML engineer",
    ]
  },
  {
    id: "fx", name: "Fixars Group", prefix: "FX", geo: "NG", tier: "Incubating",
    color: "#ea580c",
    description: "Super app parent — unified auth, community layer, holding company for all NG sub-entities",
    status: "Pending CAC", stage: "Registration & Architecture",
    tasks: { total: 30, done: 4, inProgress: 3, blocked: 1, backlog: 22 },
    team: {
      filled: 0, total: 6,
      roles: [
        { title: "CTO / Lead Architect", priority: "CRITICAL", status: "Hiring" },
        { title: "Full-Stack Developer", priority: "CRITICAL", status: "Hiring" },
        { title: "Product Designer (Platform)", priority: "HIGH", status: "Hiring" },
        { title: "Community & University Relations", priority: "HIGH", status: "Hiring" },
        { title: "Business Ops & Finance", priority: "HIGH", status: "Hiring" },
        { title: "Mobile Developer", priority: "CRITICAL", status: "Hiring" },
      ]
    },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 2, commits7d: 0, prsOpen: 0, lastActivity: "Architecture planning" },
    milestones: [
      { name: "CAC Registration", target: "2026-03", progress: 15 },
      { name: "Auth/Identity Layer", target: "2026-06", progress: 5 },
      { name: "First Sub-App Live", target: "2026-09", progress: 0 },
    ],
    equity: [
      { name: "Ade (Founder)", percent: 95, notes: "Fully vested" },
      { name: "Reserved Pool", percent: 5, notes: "Future co-founders/investors" },
    ],
    adeEffectiveOwnership: 95,
    weeklyFocus: "Wed PM + Thu AM",
    nextActions: [
      "Begin CAC registration for parent entity",
      "Design super app architecture",
      "Begin recruiting CTO / Lead Architect",
    ]
  },
  {
    id: "cn", name: "ConceptNexus", prefix: "CN", geo: "NG", tier: "Parked",
    color: "#d97706",
    description: "Idea bank: submit, validate, and develop concepts, projects, and ideas",
    status: "Planning", stage: "Under Fixars",
    parent: "Fixars Group (51%)",
    tasks: { total: 8, done: 0, inProgress: 0, blocked: 0, backlog: 8 },
    team: { filled: 0, total: 0, roles: [] },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [],
    equity: [
      { name: "Fixars Group Ltd", percent: 51, notes: "Parent holding" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Team Pool", percent: 24, notes: "Future team" },
      { name: "Investor Reserve", percent: 10, notes: "Future rounds" },
    ],
    adeEffectiveOwnership: 63.45,
    nextActions: ["Awaits Fixars Group platform foundation"]
  },
  {
    id: "sc", name: "SkillsCanvas", prefix: "SC", geo: "NG", tier: "Parked",
    color: "#d97706",
    description: "Talent repository: list skills, hire talent, access training and upskilling",
    status: "Planning", stage: "Under Fixars",
    parent: "Fixars Group (51%)",
    tasks: { total: 8, done: 0, inProgress: 0, blocked: 0, backlog: 8 },
    team: { filled: 0, total: 0, roles: [] },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [],
    equity: [
      { name: "Fixars Group Ltd", percent: 51, notes: "Parent holding" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Team Pool", percent: 24, notes: "Future team" },
      { name: "Investor Reserve", percent: 10, notes: "Future rounds" },
    ],
    adeEffectiveOwnership: 63.45,
    nextActions: ["Awaits Fixars Group platform foundation"]
  },
  {
    id: "cb", name: "CollabBoard", prefix: "CB", geo: "NG", tier: "Parked",
    color: "#d97706",
    description: "Collaboration sandbox: templates, agreements, tools for joint project work",
    status: "Planning", stage: "Under Fixars",
    parent: "Fixars Group (51%)",
    tasks: { total: 8, done: 0, inProgress: 0, blocked: 0, backlog: 8 },
    team: { filled: 0, total: 0, roles: [] },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [],
    equity: [
      { name: "Fixars Group Ltd", percent: 51, notes: "Parent holding" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Team Pool", percent: 24, notes: "Future team" },
      { name: "Investor Reserve", percent: 10, notes: "Future rounds" },
    ],
    adeEffectiveOwnership: 63.45,
    nextActions: ["Awaits Fixars Group platform foundation"]
  },
  {
    id: "vd", name: "VestDen", prefix: "VD", geo: "NG", tier: "Parked",
    color: "#d97706",
    description: "Prediction/staking marketplace: stake on ideas, fund impactful projects",
    status: "Planning", stage: "Under Fixars",
    parent: "Fixars Group (51%)",
    tasks: { total: 6, done: 0, inProgress: 0, blocked: 0, backlog: 6 },
    team: { filled: 0, total: 0, roles: [] },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [],
    equity: [
      { name: "Fixars Group Ltd", percent: 51, notes: "Parent holding" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Team Pool", percent: 24, notes: "Future team" },
      { name: "Investor Reserve", percent: 10, notes: "Future rounds" },
    ],
    adeEffectiveOwnership: 63.45,
    nextActions: ["Regulatory considerations needed", "Awaits Fixars platform"]
  },
  {
    id: "pp", name: "PayPaddy", prefix: "PP", geo: "NG", tier: "Parked",
    color: "#d97706",
    description: "Escrow platform: secure payments for transactions between parties",
    status: "Planning", stage: "Under Fixars",
    parent: "Fixars Group (51%)",
    tasks: { total: 4, done: 0, inProgress: 0, blocked: 0, backlog: 4 },
    team: { filled: 0, total: 0, roles: [] },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [],
    equity: [
      { name: "Fixars Group Ltd", percent: 51, notes: "Parent holding" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Team Pool", percent: 24, notes: "Future team" },
      { name: "Investor Reserve", percent: 10, notes: "Future rounds" },
    ],
    adeEffectiveOwnership: 63.45,
    nextActions: ["Fintech licensing needed", "Awaits Fixars platform"]
  },
  {
    id: "fs", name: "FaShop", prefix: "FS", geo: "NG", tier: "Parked",
    color: "#a3a3a3",
    description: "Fashion marketplace (details TBD)",
    status: "Concept", stage: "Under Fixars",
    parent: "Fixars Group (51%)",
    tasks: { total: 2, done: 0, inProgress: 0, blocked: 0, backlog: 2 },
    team: { filled: 0, total: 0, roles: [] },
    regs: { domain: true, company: false, bank: false, legal: false },
    github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
    milestones: [],
    equity: [
      { name: "Fixars Group Ltd", percent: 51, notes: "Parent holding" },
      { name: "Ade (Personal)", percent: 15, notes: "Fully vested" },
      { name: "Team Pool", percent: 24, notes: "Future team" },
      { name: "Investor Reserve", percent: 10, notes: "Future rounds" },
    ],
    adeEffectiveOwnership: 63.45,
    nextActions: ["Lower priority — Phase 3"]
  },
];

export const DEFAULT_SCHEDULE: ScheduleEntry[] = [
  { day: "Monday", am: "TruCycle: Product & Dev", pm: "TruCycle: Ops & Partnerships", notes: "Deepest work, most advanced venture" },
  { day: "Tuesday", am: "DepositGuard: Strategy & Legal", pm: "DepositGuard: Tech Build", notes: "Second active venture" },
  { day: "Wednesday", am: "TruCycle: Team & Ops", pm: "Fixars: Registration & Setup", notes: "UK morning, Nigeria afternoon" },
  { day: "Thursday", am: "Fixars: Architecture & Design", pm: "PathMate: Research & Validation", notes: "Incubating ventures" },
  { day: "Friday", am: "Admin: Finances, Legal, Domains", pm: "Strategic Review & Planning", notes: "Overhead + forward-looking" },
  { day: "Weekend", am: "Creative / Content", pm: "Rest & Recharge", notes: "Protect this time" },
];

export function getPortfolioStats(ventures: Venture[]) {
  const totalTasks = ventures.reduce((s, v) => s + v.tasks.total, 0);
  const doneTasks = ventures.reduce((s, v) => s + v.tasks.done, 0);
  const blockedTasks = ventures.reduce((s, v) => s + v.tasks.blocked, 0);
  const inProgressTasks = ventures.reduce((s, v) => s + v.tasks.inProgress, 0);
  const totalTeamNeeded = ventures.reduce((s, v) => s + v.team.total, 0);
  const totalTeamFilled = ventures.reduce((s, v) => s + v.team.filled, 0);
  const regsComplete = ventures.reduce((s, v) => s + Object.values(v.regs).filter(Boolean).length, 0);
  const regsTotal = ventures.length * 4;
  const activeBuilds = ventures.filter(v => v.tier === "Active Build").length;
  const incubating = ventures.filter(v => v.tier === "Incubating").length;
  const parked = ventures.filter(v => v.tier === "Parked").length;
  const ukCount = ventures.filter(v => v.geo === "UK").length;
  const ngCount = ventures.filter(v => v.geo === "NG").length;

  return {
    totalVentures: ventures.length,
    totalTasks, doneTasks, blockedTasks, inProgressTasks,
    taskCompletionPct: totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0,
    totalTeamNeeded, totalTeamFilled,
    teamGap: totalTeamNeeded - totalTeamFilled,
    regsComplete, regsTotal,
    regsPct: regsTotal > 0 ? Math.round((regsComplete / regsTotal) * 100) : 0,
    activeBuilds, incubating, parked,
    ukCount, ngCount,
  };
}

// AI assistant logic — analyses portfolio data and answers questions
export function generateAIResponse(query: string, ventures: Venture[], schedule: ScheduleEntry[]): string {
  const q = query.toLowerCase();
  const stats = getPortfolioStats(ventures);
  const criticalHires = ventures.flatMap(v => v.team.roles.filter(r => r.priority === "CRITICAL" && r.status === "Hiring").map(r => ({ venture: v.name, role: r.title })));
  const blockedVentures = ventures.filter(v => v.tasks.blocked > 0);
  const overdue = ventures.flatMap(v => v.milestones.filter(m => { const [y, mo] = m.target.split("-").map(Number); return new Date(y, mo - 1) <= new Date() && m.progress < 100; }).map(m => ({ venture: v.name, milestone: m.name, target: m.target, progress: m.progress })));

  if (q.includes("blind spot") || q.includes("missing") || q.includes("risk") || q.includes("worry")) {
    const risks: string[] = [];
    if (stats.teamGap > 10) risks.push(`Team gap is critical: ${stats.teamGap} of ${stats.totalTeamNeeded} roles unfilled. You're a solo founder running 11 entities — the #1 risk is burnout before key hires land.`);
    if (blockedVentures.length > 0) risks.push(`${blockedVentures.length} ventures have blocked tasks: ${blockedVentures.map(v => v.name).join(", ")}. Blocked items left unresolved become compounding delays.`);
    const noRegs = ventures.filter(v => !v.regs.company && v.tier !== "Parked");
    if (noRegs.length > 0) risks.push(`${noRegs.length} active/incubating ventures lack company registration: ${noRegs.map(v => v.name).join(", ")}. Can't open banks, sign contracts, or hire without this.`);
    if (overdue.length > 0) risks.push(`${overdue.length} milestones are past due: ${overdue.map(m => `${m.venture} "${m.milestone}" (${m.progress}%)`).join("; ")}.`);
    const parkedPct = Math.round((stats.parked / stats.totalVentures) * 100);
    if (parkedPct > 60) risks.push(`${parkedPct}% of ventures are parked — that's actually healthy. But check quarterly if any should be promoted or retired entirely.`);
    return risks.length > 0 ? `Here are the blind spots I'm seeing:\n\n${risks.map((r, i) => `${i + 1}. ${r}`).join("\n\n")}` : "Portfolio looks balanced. Key concern remains hiring velocity — everything else flows from getting the right people in seats.";
  }

  if (q.includes("what if") || q.includes("scenario") || q.includes("park") || q.includes("promote") || q.includes("move")) {
    return "Use the Scenario panel (bottom-left toggle) to model tier changes. Drag ventures between Active Build / Incubating / Parked to see how it shifts your time allocation, hiring pipeline, and portfolio balance in real time.";
  }

  if (q.includes("hire") || q.includes("recruit") || q.includes("team")) {
    if (criticalHires.length === 0) return "All critical roles are filled. Focus on HIGH priority hires next to build depth.";
    const grouped: Record<string, string[]> = {};
    criticalHires.forEach(h => { if (!grouped[h.venture]) grouped[h.venture] = []; grouped[h.venture].push(h.role); });
    let resp = `${criticalHires.length} CRITICAL hires outstanding:\n\n`;
    Object.entries(grouped).forEach(([v, roles]) => { resp += `${v}: ${roles.join(", ")}\n`; });
    resp += `\nPriority order: TruCycle CTO (unblocks MVP) → Fixars CTO (unblocks entire NG ecosystem) → DepositGuard Lead Dev (unblocks legal model build).`;
    return resp;
  }

  if (q.includes("today") || q.includes("focus") || q.includes("now") || q.includes("priority")) {
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const today = dayNames[new Date().getDay()];
    const entry = schedule.find(s => s.day === today) || schedule.find(s => s.day === "Weekend");
    if (!entry) return "No schedule entry for today.";
    let resp = `Today is ${today}.\n\nAM: ${entry.am}\nPM: ${entry.pm}\n\n${entry.notes}`;
    if (blockedVentures.length > 0) resp += `\n\n⚠ But first, consider unblocking: ${blockedVentures.map(v => `${v.name} (${v.tasks.blocked} blocked)`).join(", ")}`;
    return resp;
  }

  if (q.includes("register") || q.includes("cac") || q.includes("companies house")) {
    const unregistered = ventures.filter(v => !v.regs.company && v.tier !== "Parked");
    if (unregistered.length === 0) return "All active/incubating ventures are registered.";
    let resp = `Registration chain:\n\n`;
    resp += `1. Fixars Group at CAC (Nigeria) — THIS IS THE CRITICAL PATH. Everything else depends on it.\n`;
    resp += `2. Fixars Laboratories at Companies House (UK) — needs Fixars Group as 51% shareholder.\n`;
    resp += `3. DepositGuard Ltd at Companies House (UK) — independent, can be done in parallel.\n`;
    resp += `4. PathMate — can wait, still in research phase.\n\n`;
    resp += `Tip: Consider registering Fixars Labs with Ade as 100% initially, then transfer 51% to Fixars Group post-CAC to avoid blocking.`;
    return resp;
  }

  if (q.includes("equity") || q.includes("ownership") || q.includes("cap table")) {
    const highest = [...ventures].sort((a, b) => b.adeEffectiveOwnership - a.adeEffectiveOwnership).slice(0, 3);
    const lowest = [...ventures].sort((a, b) => a.adeEffectiveOwnership - b.adeEffectiveOwnership).slice(0, 3);
    return `Your ownership ranges from ${lowest[0].adeEffectiveOwnership}% (${lowest[0].name}) to ${highest[0].adeEffectiveOwnership}% (${highest[0].name}).\n\nHighest control: ${highest.map(v => `${v.name} (${v.adeEffectiveOwnership}%)`).join(", ")}\nLowest control: ${lowest.map(v => `${v.name} (${v.adeEffectiveOwnership}%)`).join(", ")}\n\nKey: Fixars sub-entities have 63.45% effective via dual-layer (95% of parent × 51% + 15% direct). This is strong — majority control is maintained while leaving room for team equity.`;
  }

  if (q.includes("add") || q.includes("new venture") || q.includes("new project")) {
    return "Click the '+' button in the header bar to add a new venture. It'll start as Parked by default — you can fill in details and promote it to Incubating or Active Build when ready. All charts and stats update instantly.";
  }

  // Default portfolio summary
  return `Portfolio: ${stats.totalVentures} ventures (${stats.activeBuilds} active, ${stats.incubating} incubating, ${stats.parked} parked).\n\nTasks: ${stats.doneTasks}/${stats.totalTasks} done (${stats.taskCompletionPct}%), ${stats.blockedTasks} blocked.\nTeam: ${stats.totalTeamFilled}/${stats.totalTeamNeeded} filled (${stats.teamGap} gap).\nRegs: ${stats.regsComplete}/${stats.regsTotal} (${stats.regsPct}%).\n\nAsk me about: blind spots, hiring priorities, today's focus, registration chain, equity breakdown, or what-if scenarios.`;
}
