import { useState, useCallback, useRef, useEffect } from "react";
import {
  DEFAULT_VENTURES, DEFAULT_SCHEDULE, getPortfolioStats, generateAIResponse,
  type Venture, type Tier, type Geo, type ScheduleEntry, type ChatMessage,
} from "./data/ventures";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BarChart3, Building2, Users, AlertTriangle, CheckCircle2, Clock,
  Globe, ChevronRight, Calendar, Brain, TrendingUp,
  GitBranch, Shield, Zap, Target, CircleDot,
  LayoutDashboard, FolderKanban, PieChart, CalendarDays, Lightbulb,
  Pencil, Save, X, Plus, MessageCircle, Send, Trash2, ArrowUpDown,
  ChevronDown, ChevronUp,
} from "lucide-react";
import {
  PieChart as RPieChart, Pie, Cell, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip,
} from "recharts";

const tierColors: Record<Tier, string> = { "Active Build": "#16a34a", "Incubating": "#2563eb", "Parked": "#a3a3a3" };
const tierBg: Record<Tier, string> = { "Active Build": "#dcfce7", "Incubating": "#dbeafe", "Parked": "#f5f5f5" };
const geoFlag: Record<Geo, string> = { UK: "\u{1F1EC}\u{1F1E7}", NG: "\u{1F1F3}\u{1F1EC}" };
const COLORS = ["#16a34a", "#2563eb", "#7c3aed", "#ea580c", "#0891b2", "#d97706", "#a3a3a3", "#ec4899", "#14b8a6"];

type Page = "overview" | "ventures" | "equity" | "schedule" | "insights";

/* ── Editable Field ── */
function EditableField({ value, onSave, type = "text", options, className = "" }: {
  value: string | number; onSave: (v: string) => void; type?: "text" | "number" | "select" | "textarea";
  options?: string[]; className?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(value));
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(null);

  useEffect(() => { if (editing && inputRef.current) inputRef.current.focus(); }, [editing]);

  if (!editing) {
    return (
      <span className={`group cursor-pointer inline-flex items-center gap-1 hover:bg-blue-50 rounded px-0.5 -mx-0.5 transition-colors ${className}`}
        onClick={() => { setDraft(String(value)); setEditing(true); }}>
        <span>{value}</span>
        <Pencil size={9} className="opacity-0 group-hover:opacity-50 transition-opacity shrink-0" />
      </span>
    );
  }

  const save = () => { onSave(draft); setEditing(false); };
  const cancel = () => setEditing(false);

  if (type === "select" && options) {
    return (
      <select ref={inputRef as any} value={draft} onChange={e => { onSave(e.target.value); setEditing(false); }}
        onBlur={cancel} className="text-xs border rounded px-1 py-0.5 bg-white">
        {options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    );
  }
  if (type === "textarea") {
    return (
      <div className="flex gap-1 items-start">
        <textarea ref={inputRef as any} value={draft} onChange={e => setDraft(e.target.value)}
          onKeyDown={e => { if (e.key === "Escape") cancel(); if (e.key === "Enter" && e.metaKey) save(); }}
          className="text-xs border rounded px-1.5 py-1 w-full min-h-[60px] resize-y" />
        <Button size="sm" variant="ghost" className="h-5 w-5 p-0" onClick={save}><Save size={10} /></Button>
        <Button size="sm" variant="ghost" className="h-5 w-5 p-0" onClick={cancel}><X size={10} /></Button>
      </div>
    );
  }

  return (
    <span className="inline-flex items-center gap-1">
      <input ref={inputRef as any} type={type} value={draft} onChange={e => setDraft(e.target.value)}
        onKeyDown={e => { if (e.key === "Enter") save(); if (e.key === "Escape") cancel(); }}
        onBlur={save} className={`border rounded px-1 py-0 ${type === "number" ? "w-12" : "w-auto"} text-xs`} />
    </span>
  );
}

/* ── Stat Card ── */
function StatCard({ label, value, sub, icon: Icon, accent }: {
  label: string; value: string | number; sub: string; icon: typeof BarChart3; accent: string;
}) {
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="pt-4 pb-3 px-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-bold mt-0.5" style={{ color: accent }}>{value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>
          </div>
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: accent + "15" }}>
            <Icon size={18} style={{ color: accent }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ── Venture Card (with editable tier) ── */
function VentureCard({ v, onClick, onUpdate, compact }: {
  v: Venture; onClick: () => void; onUpdate: (patch: Partial<Venture>) => void; compact?: boolean;
}) {
  const pct = v.tasks.total > 0 ? Math.round((v.tasks.done / v.tasks.total) * 100) : 0;
  return (
    <Card className="hover:shadow-md transition-all border-l-4 group" style={{ borderLeftColor: v.color }}>
      <CardContent className={compact ? "py-3 px-4" : "py-4 px-4"}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 cursor-pointer" onClick={onClick}>
            <span className="text-[10px] font-bold text-white px-1.5 py-0.5 rounded" style={{ backgroundColor: v.color }}>{v.prefix}</span>
            <span className="font-semibold text-sm">{v.name}</span>
            <span className="text-xs">{geoFlag[v.geo]}</span>
          </div>
          <EditableField value={v.tier} type="select" options={["Active Build", "Incubating", "Parked"]}
            onSave={val => onUpdate({ tier: val as Tier })}
            className="text-[10px] font-semibold" />
        </div>
        {!compact && <p className="text-xs text-muted-foreground mb-3 line-clamp-1">{v.description}</p>}
        <div className="space-y-1.5 cursor-pointer" onClick={onClick}>
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">{pct}% complete</span>
            <div className="flex gap-2">
              {v.tasks.blocked > 0 && <span className="text-red-600 font-semibold flex items-center gap-0.5"><AlertTriangle size={10} /> {v.tasks.blocked}</span>}
              <span className="text-muted-foreground">{v.tasks.inProgress} active</span>
            </div>
          </div>
          <Progress value={pct} className="h-1.5" />
        </div>
        {!compact && v.milestones.length > 0 && (
          <div className="mt-3 pt-2 border-t flex items-center gap-2 text-xs text-muted-foreground">
            <Target size={11} /><span>Next: {v.milestones[0].name}</span><span className="ml-auto font-mono">{v.milestones[0].target}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── Editable Venture Detail ── */
function VentureDetail({ v, onUpdate, onDelete }: { v: Venture; onUpdate: (patch: Partial<Venture>) => void; onDelete: () => void }) {
  const pct = v.tasks.total > 0 ? Math.round((v.tasks.done / v.tasks.total) * 100) : 0;
  const equityData = v.equity.map(e => ({ name: e.name.split("(")[0].trim(), value: e.percent }));
  const [newAction, setNewAction] = useState("");

  const updateTask = (field: keyof typeof v.tasks, val: number) => {
    const tasks = { ...v.tasks, [field]: val };
    tasks.total = tasks.done + tasks.inProgress + tasks.blocked + tasks.backlog;
    onUpdate({ tasks });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg shrink-0" style={{ backgroundColor: v.color }}>{v.prefix}</div>
        <div className="flex-1 min-w-0">
          <h2 className="text-xl font-bold"><EditableField value={v.name} onSave={val => onUpdate({ name: val })} /></h2>
          <div className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
            <span>{geoFlag[v.geo]}</span>
            <EditableField value={v.geo} type="select" options={["UK", "NG"]} onSave={val => onUpdate({ geo: val as Geo })} />
            <span>·</span>
            <EditableField value={v.tier} type="select" options={["Active Build", "Incubating", "Parked"]} onSave={val => onUpdate({ tier: val as Tier })} />
            <span>·</span>
            <EditableField value={v.status} onSave={val => onUpdate({ status: val })} />
          </div>
          <div className="mt-1"><EditableField value={v.description} type="textarea" onSave={val => onUpdate({ description: val })} className="text-sm text-muted-foreground" /></div>
        </div>
      </div>

      {v.parent && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg px-3 py-2 text-xs text-orange-800 flex items-center gap-2">
          <Building2 size={12} /> Parent: <EditableField value={v.parent} onSave={val => onUpdate({ parent: val })} />
        </div>
      )}

      <Tabs defaultValue="tasks">
        <TabsList className="w-full">
          <TabsTrigger value="tasks" className="flex-1 text-xs">Tasks</TabsTrigger>
          <TabsTrigger value="team" className="flex-1 text-xs">Team</TabsTrigger>
          <TabsTrigger value="equity" className="flex-1 text-xs">Equity</TabsTrigger>
          <TabsTrigger value="regs" className="flex-1 text-xs">Regs</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-3 mt-3">
          <div className="flex items-center gap-3">
            <div className="flex-1"><Progress value={pct} className="h-3" /></div>
            <span className="text-sm font-bold" style={{ color: v.color }}>{pct}%</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {([
              { label: "Done", key: "done" as const, color: "#16a34a" },
              { label: "Active", key: "inProgress" as const, color: "#2563eb" },
              { label: "Blocked", key: "blocked" as const, color: "#dc2626" },
              { label: "Backlog", key: "backlog" as const, color: "#a3a3a3" },
            ]).map(s => (
              <div key={s.label} className="text-center p-2 rounded-lg bg-muted/50">
                <div className="text-xl font-bold" style={{ color: s.color }}>
                  <EditableField value={v.tasks[s.key]} type="number" onSave={val => updateTask(s.key, Math.max(0, parseInt(val) || 0))} />
                </div>
                <div className="text-[10px] text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
          {v.milestones.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase text-muted-foreground">Milestones</h4>
              {v.milestones.map((m, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <EditableField value={m.name} onSave={val => {
                      const ms = [...v.milestones]; ms[i] = { ...ms[i], name: val }; onUpdate({ milestones: ms });
                    }} className="font-medium" />
                    <EditableField value={m.target} onSave={val => {
                      const ms = [...v.milestones]; ms[i] = { ...ms[i], target: val }; onUpdate({ milestones: ms });
                    }} className="text-muted-foreground font-mono" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={m.progress} className="h-1.5 flex-1" />
                    <EditableField value={m.progress} type="number" onSave={val => {
                      const ms = [...v.milestones]; ms[i] = { ...ms[i], progress: Math.min(100, Math.max(0, parseInt(val) || 0)) }; onUpdate({ milestones: ms });
                    }} className="text-[10px] w-8" />
                    <span className="text-[10px] text-muted-foreground">%</span>
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="space-y-1">
            <h4 className="text-xs font-semibold uppercase text-muted-foreground">Next Actions</h4>
            {v.nextActions.map((a, i) => (
              <div key={i} className="flex items-start gap-2 text-xs py-1 group/action">
                <ChevronRight size={12} className="mt-0.5 text-muted-foreground shrink-0" />
                <EditableField value={a} onSave={val => {
                  const na = [...v.nextActions]; na[i] = val; onUpdate({ nextActions: na });
                }} className="flex-1" />
                <button onClick={() => { const na = v.nextActions.filter((_, j) => j !== i); onUpdate({ nextActions: na }); }}
                  className="opacity-0 group-hover/action:opacity-100 transition-opacity"><Trash2 size={10} className="text-red-400 hover:text-red-600" /></button>
              </div>
            ))}
            <div className="flex gap-1 mt-1">
              <input value={newAction} onChange={e => setNewAction(e.target.value)} placeholder="Add action..."
                onKeyDown={e => { if (e.key === "Enter" && newAction.trim()) { onUpdate({ nextActions: [...v.nextActions, newAction.trim()] }); setNewAction(""); } }}
                className="text-xs border rounded px-2 py-1 flex-1 placeholder:text-muted-foreground/50" />
              <Button size="sm" variant="outline" className="h-6 text-xs px-2" disabled={!newAction.trim()}
                onClick={() => { onUpdate({ nextActions: [...v.nextActions, newAction.trim()] }); setNewAction(""); }}>
                <Plus size={10} />
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-3 mt-3">
          {v.team.total > 0 ? (
            <>
              <div className="flex items-center gap-2">
                <Progress value={v.team.total > 0 ? (v.team.filled / v.team.total) * 100 : 0} className="h-2 flex-1" />
                <span className="text-xs font-medium">{v.team.filled}/{v.team.total}</span>
              </div>
              {v.team.roles.map((r, i) => (
                <div key={i} className="flex items-center justify-between py-1.5 border-b last:border-0">
                  <div className="flex items-center gap-2">
                    <CircleDot size={10} className={r.status === "Filled" ? "text-green-600" : r.status === "Hiring" ? "text-amber-500" : "text-gray-400"} />
                    <span className="text-xs">{r.title}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <EditableField value={r.status} type="select" options={["Filled", "Hiring", "Later"]}
                      onSave={val => {
                        const roles = [...v.team.roles]; roles[i] = { ...roles[i], status: val as any };
                        const filled = roles.filter(r => r.status === "Filled").length;
                        onUpdate({ team: { ...v.team, roles, filled } });
                      }} className="text-[9px]" />
                  </div>
                </div>
              ))}
            </>
          ) : (
            <p className="text-xs text-muted-foreground py-4 text-center">Team not yet formed. Awaits parent platform.</p>
          )}
        </TabsContent>

        <TabsContent value="equity" className="space-y-3 mt-3">
          <div className="flex items-center gap-4">
            <div className="w-28 h-28">
              <ResponsiveContainer width="100%" height="100%">
                <RPieChart>
                  <Pie data={equityData} cx="50%" cy="50%" innerRadius={25} outerRadius={50} dataKey="value" strokeWidth={1}>
                    {equityData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                </RPieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1">
              {v.equity.map((e, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="flex-1 truncate">{e.name}</span>
                  <EditableField value={e.percent} type="number" onSave={val => {
                    const eq = [...v.equity]; eq[i] = { ...eq[i], percent: parseFloat(val) || 0 }; onUpdate({ equity: eq });
                  }} className="font-bold" />
                  <span className="text-[10px]">%</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="text-xs text-green-800 font-medium">Ade's Effective Ownership</div>
            <div className="text-2xl font-bold text-green-700">
              <EditableField value={v.adeEffectiveOwnership} type="number"
                onSave={val => onUpdate({ adeEffectiveOwnership: parseFloat(val) || 0 })} />%
            </div>
          </div>
        </TabsContent>

        <TabsContent value="regs" className="space-y-3 mt-3">
          <div className="grid grid-cols-2 gap-3">
            {([
              { label: "Domain", key: "domain" as const, icon: Globe },
              { label: "Company Reg", key: "company" as const, icon: Building2 },
              { label: "Bank Account", key: "bank" as const, icon: Shield },
              { label: "Legal Docs", key: "legal" as const, icon: Shield },
            ]).map(r => (
              <button key={r.key} onClick={() => onUpdate({ regs: { ...v.regs, [r.key]: !v.regs[r.key] } })}
                className={`flex items-center gap-2 p-3 rounded-lg transition-colors cursor-pointer ${v.regs[r.key] ? "bg-green-50 border border-green-200 hover:bg-green-100" : "bg-red-50 border border-red-200 hover:bg-red-100"}`}>
                {v.regs[r.key] ? <CheckCircle2 size={14} className="text-green-600" /> : <Clock size={14} className="text-red-500" />}
                <span className={`text-xs font-medium ${v.regs[r.key] ? "text-green-800" : "text-red-800"}`}>{r.label}</span>
              </button>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground text-center">Click to toggle registration status</p>
        </TabsContent>
      </Tabs>

      <Separator />
      <Button variant="destructive" size="sm" className="w-full text-xs" onClick={onDelete}>
        <Trash2 size={12} className="mr-1" /> Remove Venture
      </Button>
    </div>
  );
}

/* ── AI Chat Panel ── */
function AIChatPanel({ ventures, schedule, isOpen, onToggle }: {
  ventures: Venture[]; schedule: ScheduleEntry[]; isOpen: boolean; onToggle: () => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([{
    id: "welcome", role: "assistant", content: "Hey Ade. I'm your portfolio assistant. Ask me about blind spots, hiring priorities, today's focus, registration chain, equity breakdown, or what-if scenarios.\n\nTry: \"What are my blind spots?\"",
    timestamp: new Date(),
  }]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg: ChatMessage = { id: `u-${Date.now()}`, role: "user", content: input.trim(), timestamp: new Date() };
    const aiReply: ChatMessage = { id: `a-${Date.now()}`, role: "assistant", content: generateAIResponse(input.trim(), ventures, schedule), timestamp: new Date() };
    setMessages(prev => [...prev, userMsg, aiReply]);
    setInput("");
  };

  if (!isOpen) {
    return (
      <button onClick={onToggle}
        className="fixed bottom-6 right-6 w-14 h-14 bg-zinc-900 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-zinc-700 transition-colors z-50">
        <MessageCircle size={22} />
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-96 h-[500px] bg-white rounded-xl shadow-2xl border flex flex-col z-50 overflow-hidden">
      <div className="bg-zinc-900 text-white px-4 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Brain size={16} />
          <span className="text-sm font-semibold">Portfolio Assistant</span>
          <span className="w-2 h-2 bg-green-400 rounded-full" />
        </div>
        <button onClick={onToggle} className="hover:bg-zinc-700 rounded p-1"><X size={16} /></button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] rounded-lg px-3 py-2 text-xs whitespace-pre-wrap leading-relaxed ${
              msg.role === "user" ? "bg-zinc-900 text-white" : "bg-zinc-100 text-zinc-800"
            }`}>{msg.content}</div>
          </div>
        ))}
      </div>

      <div className="border-t p-2 flex gap-2 shrink-0">
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter") sendMessage(); }}
          placeholder="Ask about your portfolio..."
          className="flex-1 text-xs border rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-zinc-300" />
        <Button size="sm" className="h-8 w-8 p-0" onClick={sendMessage} disabled={!input.trim()}>
          <Send size={14} />
        </Button>
      </div>

      <div className="px-2 pb-2 flex gap-1 flex-wrap shrink-0">
        {["What are my blind spots?", "Today's focus", "Hiring priorities", "Registration chain"].map(q => (
          <button key={q} onClick={() => { setInput(q); }}
            className="text-[9px] bg-zinc-100 hover:bg-zinc-200 rounded-full px-2 py-0.5 text-zinc-600 transition-colors">{q}</button>
        ))}
      </div>
    </div>
  );
}

/* ── Add Venture Dialog ── */
function AddVentureForm({ onAdd, onCancel }: { onAdd: (v: Venture) => void; onCancel: () => void }) {
  const [name, setName] = useState("");
  const [prefix, setPrefix] = useState("");
  const [geo, setGeo] = useState<Geo>("UK");
  const [desc, setDesc] = useState("");
  const [tier, setTier] = useState<Tier>("Parked");

  const submit = () => {
    if (!name.trim() || !prefix.trim()) return;
    const id = prefix.toLowerCase().replace(/[^a-z0-9]/g, "");
    const newVenture: Venture = {
      id, name: name.trim(), prefix: prefix.trim().toUpperCase(), geo, tier,
      color: tier === "Active Build" ? "#16a34a" : tier === "Incubating" ? "#2563eb" : "#a3a3a3",
      description: desc.trim() || "New venture", status: "New", stage: "Planning",
      tasks: { total: 0, done: 0, inProgress: 0, blocked: 0, backlog: 0 },
      team: { filled: 0, total: 0, roles: [] },
      regs: { domain: false, company: false, bank: false, legal: false },
      github: { repos: 0, commits7d: 0, prsOpen: 0, lastActivity: "Not started" },
      milestones: [], equity: [], adeEffectiveOwnership: 100, nextActions: [],
    };
    onAdd(newVenture);
  };

  return (
    <Card className="border-2 border-dashed border-blue-300 bg-blue-50/50">
      <CardContent className="pt-4 space-y-3">
        <h3 className="text-sm font-semibold flex items-center gap-2"><Plus size={14} /> Add New Venture</h3>
        <div className="grid grid-cols-2 gap-2">
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Venture name" className="text-xs border rounded px-2 py-1.5 col-span-2" />
          <input value={prefix} onChange={e => setPrefix(e.target.value)} placeholder="Prefix (e.g. TC)" className="text-xs border rounded px-2 py-1.5" maxLength={3} />
          <select value={geo} onChange={e => setGeo(e.target.value as Geo)} className="text-xs border rounded px-2 py-1.5">
            <option value="UK">UK</option><option value="NG">NG</option>
          </select>
          <select value={tier} onChange={e => setTier(e.target.value as Tier)} className="text-xs border rounded px-2 py-1.5">
            <option value="Active Build">Active Build</option><option value="Incubating">Incubating</option><option value="Parked">Parked</option>
          </select>
          <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Description" className="text-xs border rounded px-2 py-1.5" />
        </div>
        <div className="flex gap-2">
          <Button size="sm" className="text-xs" onClick={submit} disabled={!name.trim() || !prefix.trim()}>Add Venture</Button>
          <Button size="sm" variant="outline" className="text-xs" onClick={onCancel}>Cancel</Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ── Overview Page ── */
function OverviewPage({ ventures, schedule, onSelectVenture }: { ventures: Venture[]; schedule: ScheduleEntry[]; onSelectVenture: (v: Venture) => void }) {
  const stats = getPortfolioStats(ventures);
  const blockedVentures = ventures.filter(v => v.tasks.blocked > 0);
  const activeVentures = ventures.filter(v => v.tier === "Active Build" || v.tier === "Incubating");
  const taskBarData = ventures.filter(v => v.tasks.total > 0).map(v => ({ name: v.prefix, done: v.tasks.done, active: v.tasks.inProgress, blocked: v.tasks.blocked, backlog: v.tasks.backlog }));
  const tierPieData = [{ name: "Active Build", value: stats.activeBuilds }, { name: "Incubating", value: stats.incubating }, { name: "Parked", value: stats.parked }];
  const today = new Date();
  const dayOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][today.getDay()];
  const todaySchedule = schedule.find(s => s.day === dayOfWeek) || schedule.find(s => s.day === "Weekend");

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatCard label="Ventures" value={stats.totalVentures} sub={`${stats.ukCount} UK · ${stats.ngCount} NG`} icon={Building2} accent="#1e40af" />
        <StatCard label="Tasks Done" value={`${stats.doneTasks}/${stats.totalTasks}`} sub={`${stats.taskCompletionPct}% complete`} icon={CheckCircle2} accent="#16a34a" />
        <StatCard label="Blocked" value={stats.blockedTasks} sub={stats.blockedTasks > 0 ? "Needs attention" : "All clear"} icon={AlertTriangle} accent={stats.blockedTasks > 0 ? "#dc2626" : "#16a34a"} />
        <StatCard label="Team Gap" value={`${stats.totalTeamFilled}/${stats.totalTeamNeeded}`} sub={`${stats.teamGap} roles to fill`} icon={Users} accent="#7c3aed" />
        <StatCard label="Registrations" value={`${stats.regsComplete}/${stats.regsTotal}`} sub={`${stats.regsPct}% complete`} icon={Shield} accent="#ea580c" />
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="md:col-span-2 border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2"><Calendar size={14} /> Today's Focus — {dayOfWeek}</CardTitle>
          </CardHeader>
          <CardContent>
            {todaySchedule && (
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-blue-50 rounded-lg p-3">
                  <div className="text-[10px] font-semibold text-blue-600 uppercase">Morning</div>
                  <div className="text-sm font-medium mt-1">{todaySchedule.am}</div>
                </div>
                <div className="bg-amber-50 rounded-lg p-3">
                  <div className="text-[10px] font-semibold text-amber-600 uppercase">Afternoon</div>
                  <div className="text-sm font-medium mt-1">{todaySchedule.pm}</div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        {blockedVentures.length > 0 && (
          <Card className="border-0 shadow-sm border-l-4 border-l-red-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 text-red-700"><AlertTriangle size={14} /> Blockers</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {blockedVentures.map(v => (
                <div key={v.id} className="flex items-center justify-between cursor-pointer hover:bg-red-50 rounded p-1.5 -mx-1.5" onClick={() => onSelectVenture(v)}>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-bold text-white px-1 rounded" style={{ backgroundColor: v.color }}>{v.prefix}</span>
                    <span className="text-xs font-medium">{v.name}</span>
                  </div>
                  <Badge variant="destructive" className="text-[9px]">{v.tasks.blocked} blocked</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="md:col-span-2 border-0 shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2"><BarChart3 size={14} /> Task Breakdown</CardTitle></CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={taskBarData} barSize={16}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <RTooltip contentStyle={{ fontSize: 11 }} />
                  <Bar dataKey="done" stackId="a" fill="#16a34a" name="Done" />
                  <Bar dataKey="active" stackId="a" fill="#2563eb" name="Active" />
                  <Bar dataKey="blocked" stackId="a" fill="#dc2626" name="Blocked" />
                  <Bar dataKey="backlog" stackId="a" fill="#e5e5e5" name="Backlog" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2"><PieChart size={14} /> Portfolio Mix</CardTitle></CardHeader>
          <CardContent>
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <RPieChart>
                  <Pie data={tierPieData} cx="50%" cy="50%" outerRadius={60} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                    {tierPieData.map((_, i) => <Cell key={i} fill={Object.values(tierColors)[i]} />)}
                  </Pie>
                </RPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><Zap size={14} /> Active & Incubating</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {activeVentures.map(v => (
            <VentureCard key={v.id} v={v} onClick={() => onSelectVenture(v)}
              onUpdate={patch => onSelectVenture({ ...v, ...patch })} />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── Ventures Page ── */
function VenturesPage({ ventures, onSelectVenture, onUpdateVenture, onAddVenture }: {
  ventures: Venture[]; onSelectVenture: (v: Venture) => void;
  onUpdateVenture: (id: string, patch: Partial<Venture>) => void; onAddVenture: (v: Venture) => void;
}) {
  const [tierFilter, setTierFilter] = useState<Tier | "all">("all");
  const [geoFilter, setGeoFilter] = useState<Geo | "all">("all");
  const [showAdd, setShowAdd] = useState(false);
  const filtered = ventures.filter(v => {
    if (tierFilter !== "all" && v.tier !== tierFilter) return false;
    if (geoFilter !== "all" && v.geo !== geoFilter) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        {(["all", "Active Build", "Incubating", "Parked"] as const).map(t => (
          <Button key={t} variant={tierFilter === t ? "default" : "outline"} size="sm" className="text-xs h-7" onClick={() => setTierFilter(t)}>{t === "all" ? "All Tiers" : t}</Button>
        ))}
        <Separator orientation="vertical" className="h-5" />
        {(["all", "UK", "NG"] as const).map(g => (
          <Button key={g} variant={geoFilter === g ? "default" : "outline"} size="sm" className="text-xs h-7" onClick={() => setGeoFilter(g)}>{g === "all" ? "All Geos" : `${geoFlag[g]} ${g}`}</Button>
        ))}
      </div>

      {showAdd ? (
        <AddVentureForm onAdd={v => { onAddVenture(v); setShowAdd(false); }} onCancel={() => setShowAdd(false)} />
      ) : (
        <Button variant="outline" size="sm" className="text-xs w-full border-dashed" onClick={() => setShowAdd(true)}>
          <Plus size={12} className="mr-1" /> Add New Venture
        </Button>
      )}

      <div className="grid md:grid-cols-2 gap-3">
        {filtered.map(v => (
          <VentureCard key={v.id} v={v} onClick={() => onSelectVenture(v)}
            onUpdate={patch => onUpdateVenture(v.id, patch)} />
        ))}
      </div>
      {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground text-sm">No ventures match current filters.</div>}
    </div>
  );
}

/* ── Equity Page ── */
function EquityPage({ ventures }: { ventures: Venture[] }) {
  const ukVentures = ventures.filter(v => v.geo === "UK");
  const ngVentures = ventures.filter(v => v.geo === "NG");
  const ownershipData = ventures.filter(v => v.tier !== "Parked" || v.id === "fx").map(v => ({ name: v.prefix, ownership: v.adeEffectiveOwnership, fill: v.color }));

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-sm bg-gradient-to-r from-green-50 to-emerald-50">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2 text-green-800"><TrendingUp size={14} /> Ade's Effective Ownership</CardTitle></CardHeader>
        <CardContent>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ownershipData} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e0e0e0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} unit="%" />
                <RTooltip contentStyle={{ fontSize: 11 }} />
                <Bar dataKey="ownership" fill="#16a34a" radius={[6, 6, 0, 0]} label={{ position: "top", fontSize: 10, formatter: (v: number) => `${v}%` }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      <div className="grid md:grid-cols-2 gap-3">
        {[...ukVentures, ...ngVentures].filter(v => v.tier !== "Parked" || v.id === "fx").map(v => (
          <Card key={v.id} className="border-0 shadow-sm">
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] font-bold text-white px-1.5 py-0.5 rounded" style={{ backgroundColor: v.color }}>{v.prefix}</span>
                <span className="font-semibold text-sm">{v.name}</span>
                <span className="text-xs">{geoFlag[v.geo]}</span>
                <span className="ml-auto text-lg font-bold" style={{ color: v.color }}>{v.adeEffectiveOwnership}%</span>
              </div>
              <div className="space-y-1">
                {v.equity.map((e, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="flex-1 truncate text-muted-foreground">{e.name}</span>
                    <span className="font-semibold">{e.percent}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ── Schedule Page ── */
function SchedulePage({ schedule, onUpdateSchedule }: { schedule: ScheduleEntry[]; onUpdateSchedule: (idx: number, patch: Partial<ScheduleEntry>) => void }) {
  const today = new Date();
  const dayOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][today.getDay()];
  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2"><CalendarDays size={14} /> Weekly Context-Switching Rhythm</CardTitle></CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground mb-4">Click any cell to edit. Your week is like a DJ set — you schedule dedicated sets per venture. When you're in a block, you're ONLY on that venture.</p>
          <div className="space-y-2">
            {schedule.map((s, idx) => {
              const isToday = s.day === dayOfWeek || (["Saturday", "Sunday"].includes(dayOfWeek) && s.day === "Weekend");
              return (
                <div key={s.day} className={`grid grid-cols-[100px_1fr_1fr_1fr] gap-3 p-3 rounded-lg text-xs ${isToday ? "bg-blue-50 border border-blue-200 ring-2 ring-blue-100" : "bg-muted/30"}`}>
                  <div className="font-semibold flex items-center gap-1">{isToday && <CircleDot size={10} className="text-blue-600" />}{s.day}</div>
                  <div className="bg-white/60 rounded px-2 py-1">
                    <span className="text-[9px] font-semibold text-blue-600 uppercase">AM</span>
                    <div className="font-medium"><EditableField value={s.am} onSave={val => onUpdateSchedule(idx, { am: val })} /></div>
                  </div>
                  <div className="bg-white/60 rounded px-2 py-1">
                    <span className="text-[9px] font-semibold text-amber-600 uppercase">PM</span>
                    <div className="font-medium"><EditableField value={s.pm} onSave={val => onUpdateSchedule(idx, { pm: val })} /></div>
                  </div>
                  <div className="text-muted-foreground self-center"><EditableField value={s.notes} onSave={val => onUpdateSchedule(idx, { notes: val })} /></div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ── Insights Page ── */
function InsightsPage({ ventures }: { ventures: Venture[] }) {
  const stats = getPortfolioStats(ventures);
  const criticalHires = ventures.flatMap(v => v.team.roles.filter(r => r.priority === "CRITICAL" && r.status === "Hiring").map(r => ({ venture: v.name, prefix: v.prefix, color: v.color, role: r.title })));
  const overdueMilestones = ventures.flatMap(v => v.milestones.filter(m => { const [y, mo] = m.target.split("-").map(Number); return new Date(y, mo - 1) <= new Date() && m.progress < 100; }).map(m => ({ venture: v.name, prefix: v.prefix, color: v.color, milestone: m })));
  const healthData = ventures.filter(v => v.tier !== "Parked").map(v => {
    const taskPct = v.tasks.total > 0 ? (v.tasks.done / v.tasks.total) * 100 : 0;
    const teamPct = v.team.total > 0 ? (v.team.filled / v.team.total) * 100 : 0;
    const regPct = (Object.values(v.regs).filter(Boolean).length / 4) * 100;
    const milestonePct = v.milestones.length > 0 ? v.milestones.reduce((s, m) => s + m.progress, 0) / v.milestones.length : 0;
    return { name: v.prefix, color: v.color, tasks: Math.round(taskPct), team: Math.round(teamPct), regs: Math.round(regPct), milestones: Math.round(milestonePct) };
  });

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-sm bg-gradient-to-r from-violet-50 to-indigo-50">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2 text-violet-800"><Brain size={14} /> Live Insights (updates as you edit)</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid md:grid-cols-2 gap-3">
            <div className="bg-white rounded-lg p-3 border">
              <div className="text-xs font-semibold text-red-700 flex items-center gap-1 mb-2"><AlertTriangle size={12} /> Critical Bottleneck</div>
              <p className="text-xs text-muted-foreground"><strong>Hiring constraint:</strong> {stats.teamGap} of {stats.totalTeamNeeded} roles unfilled. {criticalHires.length} marked CRITICAL.</p>
              <p className="text-xs text-muted-foreground mt-1">Priority: TruCycle CTO (unblocks MVP) then Fixars CTO (unblocks NG ecosystem).</p>
            </div>
            <div className="bg-white rounded-lg p-3 border">
              <div className="text-xs font-semibold text-amber-700 flex items-center gap-1 mb-2"><Clock size={12} /> Registration Chain</div>
              <p className="text-xs text-muted-foreground"><strong>Fixars Group CAC is the critical path.</strong> Until registered, Fixars Labs and sub-entities are blocked.</p>
            </div>
            <div className="bg-white rounded-lg p-3 border">
              <div className="text-xs font-semibold text-blue-700 flex items-center gap-1 mb-2"><TrendingUp size={12} /> Portfolio Balance</div>
              <p className="text-xs text-muted-foreground"><strong>{stats.parked} of {stats.totalVentures} parked.</strong> {stats.activeBuilds} active builds getting {stats.activeBuilds > 0 ? "60-70%" : "0%"} of time. {stats.activeBuilds <= 3 ? "Healthy focus." : "Consider parking more to avoid spread."}</p>
            </div>
            <div className="bg-white rounded-lg p-3 border">
              <div className="text-xs font-semibold text-green-700 flex items-center gap-1 mb-2"><Globe size={12} /> Cross-Border</div>
              <p className="text-xs text-muted-foreground"><strong>{stats.ukCount} UK, {stats.ngCount} NG.</strong> Dual geography = UK funding access (SEIS/EIS) + NG talent arbitrage.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {healthData.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2"><Target size={14} /> Venture Health Scores</CardTitle></CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {healthData.map(d => (
                <div key={d.name} className="flex items-center gap-4">
                  <span className="text-[10px] font-bold text-white px-1.5 py-0.5 rounded shrink-0" style={{ backgroundColor: d.color }}>{d.name}</span>
                  <div className="flex-1 space-y-1">
                    {[{ label: "Tasks", val: d.tasks, color: "#16a34a" }, { label: "Team", val: d.team, color: "#7c3aed" }, { label: "Regs", val: d.regs, color: "#ea580c" }, { label: "Miles", val: d.milestones, color: "#2563eb" }].map(m => (
                      <div key={m.label} className="flex items-center gap-2">
                        <span className="text-[9px] w-10 text-muted-foreground">{m.label}</span>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden"><div className="h-full rounded-full transition-all duration-500" style={{ width: `${m.val}%`, backgroundColor: m.color }} /></div>
                        <span className="text-[9px] font-mono w-8 text-right">{m.val}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {criticalHires.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold flex items-center gap-2 text-red-700"><Users size={14} /> Critical Hires ({criticalHires.length})</CardTitle></CardHeader>
          <CardContent className="space-y-1.5">
            {criticalHires.map((h, i) => (
              <div key={i} className="flex items-center gap-3 py-1.5 border-b last:border-0 text-xs">
                <span className="text-[9px] font-bold text-white px-1 rounded" style={{ backgroundColor: h.color }}>{h.prefix}</span>
                <span className="text-muted-foreground">{h.venture}</span>
                <span className="font-medium flex-1">{h.role}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/* ── Main App ── */
export default function App() {
  const [page, setPage] = useState<Page>("overview");
  const [selectedVenture, setSelectedVenture] = useState<Venture | null>(null);
  const [ventures, setVentures] = useState<Venture[]>(DEFAULT_VENTURES);
  const [schedule, setSchedule] = useState<ScheduleEntry[]>(DEFAULT_SCHEDULE);
  const [chatOpen, setChatOpen] = useState(false);
  const stats = getPortfolioStats(ventures);

  const updateVenture = useCallback((id: string, patch: Partial<Venture>) => {
    setVentures(prev => prev.map(v => v.id === id ? { ...v, ...patch } : v));
    if (selectedVenture?.id === id) setSelectedVenture(prev => prev ? { ...prev, ...patch } : null);
  }, [selectedVenture]);

  const deleteVenture = useCallback((id: string) => {
    setVentures(prev => prev.filter(v => v.id !== id));
    if (selectedVenture?.id === id) setSelectedVenture(null);
  }, [selectedVenture]);

  const addVenture = useCallback((v: Venture) => {
    setVentures(prev => [...prev, v]);
  }, []);

  const updateSchedule = useCallback((idx: number, patch: Partial<ScheduleEntry>) => {
    setSchedule(prev => prev.map((s, i) => i === idx ? { ...s, ...patch } : s));
  }, []);

  const selectVenture = useCallback((v: Venture) => {
    setSelectedVenture(v);
  }, []);

  const navItems: { key: Page; label: string; icon: typeof LayoutDashboard }[] = [
    { key: "overview", label: "Overview", icon: LayoutDashboard },
    { key: "ventures", label: "Ventures", icon: FolderKanban },
    { key: "equity", label: "Equity", icon: PieChart },
    { key: "schedule", label: "Schedule", icon: CalendarDays },
    { key: "insights", label: "Insights", icon: Brain },
  ];

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col">
      <header className="bg-zinc-900 text-white px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold tracking-tight">Venture Command Center</h1>
            <p className="text-xs text-zinc-400 mt-0.5">{stats.totalVentures} entities · {stats.ukCount} UK · {stats.ngCount} NG · <span className="text-green-400">Live & Editable</span></p>
          </div>
          <div className="flex items-center gap-3">
            {stats.blockedTasks > 0 && <Badge variant="destructive" className="text-xs">{stats.blockedTasks} Blocked</Badge>}
            <div className="text-right"><div className="text-xs text-zinc-400">{new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short", year: "numeric" })}</div></div>
          </div>
        </div>
        <nav className="flex gap-1 mt-3 -mb-1">
          {navItems.map(item => (
            <button key={item.key} onClick={() => setPage(item.key)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-t-lg text-xs font-medium transition-all ${page === item.key ? "bg-zinc-50 text-zinc-900" : "text-zinc-400 hover:text-white hover:bg-zinc-800"}`}>
              <item.icon size={13} />{item.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="flex-1 flex">
        <div className={`flex-1 p-6 ${selectedVenture ? "pr-3" : ""}`}>
          {page === "overview" && <OverviewPage ventures={ventures} schedule={schedule} onSelectVenture={selectVenture} />}
          {page === "ventures" && <VenturesPage ventures={ventures} onSelectVenture={selectVenture} onUpdateVenture={updateVenture} onAddVenture={addVenture} />}
          {page === "equity" && <EquityPage ventures={ventures} />}
          {page === "schedule" && <SchedulePage schedule={schedule} onUpdateSchedule={updateSchedule} />}
          {page === "insights" && <InsightsPage ventures={ventures} />}
        </div>
        {selectedVenture && (
          <div className="w-[400px] border-l bg-white shadow-lg flex flex-col shrink-0">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <span className="text-xs font-semibold text-muted-foreground">Edit Venture</span>
              <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setSelectedVenture(null)}>Close</Button>
            </div>
            <ScrollArea className="flex-1 p-4">
              <VentureDetail
                v={ventures.find(vv => vv.id === selectedVenture.id) || selectedVenture}
                onUpdate={patch => updateVenture(selectedVenture.id, patch)}
                onDelete={() => deleteVenture(selectedVenture.id)} />
            </ScrollArea>
          </div>
        )}
      </main>

      <AIChatPanel ventures={ventures} schedule={schedule} isOpen={chatOpen} onToggle={() => setChatOpen(!chatOpen)} />

      <footer className="text-center py-3 text-[10px] text-muted-foreground border-t bg-white">
        Venture Command Center v4.0 · Live & Editable · AI Assistant · Built for Ade
      </footer>
    </div>
  );
}
