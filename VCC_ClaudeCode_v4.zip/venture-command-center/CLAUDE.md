# Venture Command Center — Claude Code Context

## What This Project Is
A personal portfolio management dashboard for Ade's multi-entity venture portfolio (11 entities across UK and Nigeria, under Fixars Group). It functions as a "second brain / executive assistant" — tracking milestones, equity, team gaps, registrations, weekly schedule, and AI-assisted insights.

## Stack
- **React 18 + TypeScript** (Vite for dev, Parcel for single-file HTML bundling)
- **Tailwind CSS 3.4.1** + **shadcn/ui** (40+ Radix UI components pre-installed)
- **Recharts** for live data visualisation
- **No backend** — all state is React in-browser. AI responses are deterministic keyword-matching functions in `src/data/ventures.ts`

## Key Files
| File | Purpose |
|------|---------|
| `src/data/ventures.ts` | All venture data, TypeScript interfaces, `generateAIResponse()`, `getPortfolioStats()` |
| `src/App.tsx` | Full app (~800 lines): all pages, inline editing, AI chat panel |
| `src/index.css` | Tailwind directives + shadcn/ui CSS variables (light/dark) |
| `src/components/ui/` | 40+ shadcn/ui components — do not modify unless adding new ones |

## Dev Commands
```bash
npm install          # Install all dependencies
npm run dev          # Start dev server at http://localhost:5173
npm run build        # TypeScript check + Vite production build
npm run bundle       # Bundle to single self-contained HTML file (bundle.html)
npm run preview      # Preview production build
```

## Architecture — Data Flow
```
ventures.ts (DEFAULT_VENTURES, DEFAULT_SCHEDULE)
    ↓ initial state
App.tsx useState([ventures, schedule])
    ↓ passed as props + callbacks
  OverviewPage / VenturesPage / EquityPage / SchedulePage / InsightsPage
    ↓ mutations via
  updateVenture(id, field, value)  ← inline EditableField component
  addVenture(venture)              ← AddVentureForm component
  deleteVenture(id)                ← VentureDetail delete button
  updateSchedule(day, period, val) ← SchedulePage editable cells
    ↓ AI reads live state
  AIChatPanel → generateAIResponse(query, ventures, schedule)
```

## Venture Data Model (key fields)
```typescript
interface Venture {
  id: string;           // e.g. "FIX", "NUB", "CEP"
  name: string;
  tier: 'Active Build' | 'Incubating' | 'Parked';
  geo: 'UK' | 'NG' | 'UK+NG';
  status: string;       // free text
  description: string;
  tasks: TaskBreakdown; // { done, active, blocked, backlog } → total auto-calculated
  milestone: Milestone; // { name, target, progress (0-100) }
  nextActions: string[];
  team: TeamInfo;       // { founded, roles: TeamRole[] }
  equity: EquityHolder[]; // { name, percentage, type }
  registration: RegChecklist; // { NG_CAC, NG_TIN, ... } booleans
  github?: GitHubInfo;
}
```

## Bundling to Single HTML
The app bundles to a fully self-contained HTML file (all JS/CSS inlined):
```bash
npm run bundle
# Output: bundle.html (~870K)
```
This file can be opened directly in any browser — no server needed. Useful for sharing a private link via Netlify Drop, GitHub Pages, etc.

## Adding New Features — Where to Edit
- **New venture fields**: Add to `Venture` interface in `ventures.ts`, add default value in `DEFAULT_VENTURES`, add `EditableField` in `VentureDetail` component in `App.tsx`
- **New AI response topics**: Add keyword branch to `generateAIResponse()` in `ventures.ts`
- **New pages/tabs**: Add tab to the nav array and new Page component in `App.tsx`
- **New shadcn/ui components**: `npx shadcn@latest add <component-name>`
- **External integrations** (Slack, Linear, Drive): Add API calls in `ventures.ts` or a new `src/services/` directory; pass fetched data into React state via `useEffect`

## External Integration Notes (Future)
The app is designed to accept external data without structural changes:
- **Slack**: Pull standup updates / blockers into `venture.nextActions[]`
- **Linear**: Sync issue counts into `venture.tasks` fields
- **Google Drive**: Pull milestone doc links into `venture.milestone.name`
- **Evernote**: Push venture notes as structured context

These integrations require a lightweight backend (Node.js/Express or Cloudflare Workers) to hold API keys securely. Claude Code can scaffold this when ready.

## Equity Structure Context
- **Fixars Group Nigeria Ltd** → owns Fixars Group UK Ltd (parent entity)
- All 11 ventures are either directly owned or subsidiaries of the above
- Equity percentages in the dashboard reflect Ade's stake in each entity

## Venture Tiers
- **Active Build**: 3 ventures currently in active development
- **Incubating**: 5 ventures with foundational work in progress
- **Parked**: 3 ventures on hold pending capacity/resources
